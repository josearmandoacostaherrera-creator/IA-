const $ = (id) => document.getElementById(id);
const promptInput = $("prompt");
const sendButton = $("sendButton");
const welcome = $("welcome");
const conversation = $("conversation");
const historyBox = $("history");
const STORAGE_KEY = "prometeo_omega_chats_v1";

let chats = loadChats();
let activeId = chats[0]?.id || createChat();
let busy = false;

function loadChats() {
  try {
    const value = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    return Array.isArray(value) ? value : [];
  } catch { return []; }
}
function saveChats() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(chats.slice(0, 30))); }
  catch { /* El chat sigue funcionando aunque el navegador no permita guardar. */ }
}
function createChat() {
  const chat = { id: crypto.randomUUID(), title: "Nueva conversación", messages: [] };
  chats.unshift(chat);
  saveChats();
  return chat.id;
}
function currentChat() { return chats.find(c => c.id === activeId); }
function renderHistory() {
  historyBox.replaceChildren();
  chats.forEach(chat => {
    const button = document.createElement("button");
    button.className = "history-item" + (chat.id === activeId ? " active" : "");
    button.textContent = chat.title;
    button.title = chat.title;
    button.addEventListener("click", () => {
      activeId = chat.id;
      renderAll();
      $("sidebar").classList.remove("open");
    });
    historyBox.append(button);
  });
}
function renderMessage(role, content, typing = false) {
  const wrap = document.createElement("article");
  wrap.className = "message " + role;
  const avatar = document.createElement("div");
  avatar.className = "avatar";
  avatar.textContent = role === "user" ? "TÚ" : "Ω";
  const body = document.createElement("div");
  body.className = "message-body";
  const head = document.createElement("div");
  head.className = "message-head";
  head.textContent = role === "user" ? "USUARIO" : "PROMETEO-Ω";
  const text = document.createElement("div");
  text.className = typing ? "typing" : "message-text";
  text.textContent = content;
  body.append(head, text);
  wrap.append(avatar, body);
  conversation.append(wrap);
  return text;
}
function renderAll() {
  const chat = currentChat();
  renderHistory();
  conversation.replaceChildren();
  const hasMessages = chat && chat.messages.length;
  welcome.classList.toggle("hidden", Boolean(hasMessages));
  conversation.classList.toggle("hidden", !hasMessages);
  if (hasMessages) chat.messages.forEach(m => renderMessage(m.role, m.content));
}
function setBusy(value) {
  busy = value;
  sendButton.disabled = value;
  sendButton.textContent = value ? "…" : "↑";
}
async function sendMessage(prefill) {
  if (busy) return;
  const content = (prefill ?? promptInput.value).trim();
  if (!content) return;
  const chat = currentChat();
  if (!chat) return;
  if (content.length > 12000) return alert("El mensaje supera el límite de 12.000 caracteres.");

  chat.messages.push({ role: "user", content });
  if (chat.messages.length === 1) chat.title = content.slice(0, 38) + (content.length > 38 ? "…" : "");
  promptInput.value = "";
  promptInput.style.height = "auto";
  saveChats();
  renderAll();
  conversation.classList.remove("hidden");
  welcome.classList.add("hidden");
  const typing = renderMessage("assistant", "PROCESANDO", true);
  setBusy(true);

  try {
    const payload = chat.messages.slice(-20).map(({ role, content }) => ({ role, content }));
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages: payload, mode: $("mode").value })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || `Error HTTP ${response.status}`);
    chat.messages.push({ role: "assistant", content: data.answer });
    typing.textContent = data.answer;
    typing.className = "message-text";
    saveChats();
    renderHistory();
  } catch (error) {
    typing.textContent = "No se pudo completar la solicitud: " + error.message;
    typing.className = "message-text";
  } finally {
    setBusy(false);
    conversation.scrollTop = conversation.scrollHeight;
  }
}
sendButton.addEventListener("click", () => sendMessage());
promptInput.addEventListener("keydown", e => {
  if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
});
promptInput.addEventListener("input", () => {
  promptInput.style.height = "auto";
  promptInput.style.height = Math.min(promptInput.scrollHeight, 180) + "px";
});
$("newChat").addEventListener("click", () => {
  activeId = createChat();
  renderAll();
  promptInput.focus();
  $("sidebar").classList.remove("open");
});
$("clearButton").addEventListener("click", () => {
  const chat = currentChat();
  if (!chat || !chat.messages.length) return;
  if (!confirm("¿Borrar los mensajes de esta conversación?")) return;
  chat.messages = [];
  chat.title = "Nueva conversación";
  saveChats();
  renderAll();
});
$("mobileMenu").addEventListener("click", () => $("sidebar").classList.toggle("open"));
$("settingsButton").addEventListener("click", () => $("settingsDialog").showModal());
$("settingsDialog").addEventListener("click", e => {
  if (e.target === $("settingsDialog")) $("settingsDialog").close();
});
document.querySelectorAll("[data-prompt]").forEach(button => {
  button.addEventListener("click", () => {
    promptInput.value = button.dataset.prompt;
    promptInput.focus();
    promptInput.setSelectionRange(promptInput.value.length, promptInput.value.length);
  });
});
async function checkHealth() {
  const dot = $("statusDot");
  try {
    const response = await fetch("/api/health");
    const data = await response.json();
    $("modelName").textContent = data.model || "No disponible";
    dot.className = data.configured ? "ok" : "bad";
    $("statusText").textContent = data.configured ? "Motor conectado" : "Falta configurar API";
  } catch {
    dot.className = "bad";
    $("statusText").textContent = "Servidor no disponible";
  }
}
renderAll();
checkHealth();
