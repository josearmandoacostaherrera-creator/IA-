# PROMETEO-Ω 1.0

Aplicación web de chat con interfaz propia y backend Node.js. La clave de OpenAI permanece en el servidor.

## Requisitos

- Node.js 20 o superior.
- Una clave API válida configurada por el titular adulto de la cuenta/proyecto.
- Acceso a internet desde el servidor.

La API se factura por separado del uso de ChatGPT. Revisa el consumo y establece límites de gasto antes de usarla.

## Ejecutar en un ordenador o servidor

1. Descomprime el proyecto.
2. Instala dependencias:

   ```bash
   npm install
   ```

3. Copia `.env.example` a `.env`.
4. Edita `.env` y coloca la clave en `OPENAI_API_KEY`. No la pegues en el navegador ni en `public/app.js`.
5. Inicia:

   ```bash
   npm start
   ```

6. Abre `http://localhost:3000`.

## Ejecutar desde Android

Es posible editar el proyecto desde Android, pero la aplicación necesita un entorno que ejecute Node.js o un servicio de alojamiento compatible. Abrir `public/index.html` directamente como archivo no conecta con el servidor ni con la API.

## Variables

| Variable | Uso | Valor inicial |
|---|---|---|
| `OPENAI_API_KEY` | Clave privada del servidor | Obligatoria |
| `OPENAI_MODEL` | Modelo API | `gpt-5.5` |
| `PORT` | Puerto web | `3000` |

Si el modelo elegido no está habilitado para el proyecto API, cambia `OPENAI_MODEL` por un modelo disponible en tu cuenta.

## Endpoints

- `GET /api/health`: estado del servidor y configuración (nunca devuelve la clave).
- `POST /api/chat`: recibe `{ "messages": [...], "mode": "auto" }` y devuelve `{ "answer": "...", "model": "..." }`.

## Seguridad incluida

- Clave solo en variable de entorno del servidor.
- `.env` excluido de Git.
- Helmet y política de contenido.
- Límite de solicitudes por IP.
- Validación de mensajes, roles, longitud y cantidad.
- Límite de cuerpo HTTP.
- Historial guardado en el almacenamiento local del navegador.

## Límites de esta versión

- No tiene cuentas de usuario ni sincronización entre dispositivos.
- El historial se guarda solo en el navegador.
- No incluye búsqueda web, voz, subida de archivos ni ejecución de código.
- El límite por IP es una protección básica; para producción pública añade autenticación, cuotas por usuario, monitoreo y protección contra abuso.
